// This is a JavaScript file

$(document).on("click","#alerta", function() {
  navigator.notification.alert("Texto", null,"Aviso","Aceito");
});


$(document).on("click","#confirm", function() {
  function confirm(buttonIndex){
    if(buttonIndex == 1){
      navigator.notification.alert("A opção 1 foi selecionada.");
    }
    else{
      navigator.notification.alert("A opção 2 foi selecionada.");
    }
  }
  navigator.notification.confirm("Escolha 1 ou 2:", confirm,"Atenção!",['1','2']);
});

$(document).on("click","#beep", function() {
  navigator.notification.beep(5);
});

$(document).on("click","#vb", function() {
  navigator.vibrate(5000);
});

function Mapa(lat, log){
        L.mapquest.key = 'vaMRkVXQx88e15gdrzd8UDugzle4zFeJ';

        var map = L.mapquest.map('map', {
          center: [lat, log],
          layers: L.mapquest.tileLayer('map'),
          zoom: 18
        });

        map.addControl(L.mapquest.control());
}

$(document).on("click","#local", function() {
    var onSuccess = function(position) {
      function Mapa(position.coords.latitude, position.coords.longitude)
    };

    function onError(error) {
        alert('code: '    + error.code    + '\n' +
              'message: ' + error.message + '\n');
    }
    navigator.geolocation.getCurrentPosition(onSuccess, onError);
});

